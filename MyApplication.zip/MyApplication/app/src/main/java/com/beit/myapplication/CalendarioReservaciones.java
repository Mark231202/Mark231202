package com.beit.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class CalendarioReservaciones extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private ArrayList<Reservacion> reservaciones;

    private LinearLayout layoutDias;
    private LinearLayout layoutHabitaciones;
    private LinearLayout layoutNombresHabitaciones;

    private TextView txtMes;

    private Button btnMesAnterior;
    private Button btnMesSiguiente;
    private Button btnCompartirMeses;

    private HorizontalScrollView scrollHorizontal;

    private ScrollView scrollHabitaciones;
    private ScrollView scrollCeldas;

    private Calendar calendarioActual;


    // =========================================================
    // HABITACIONES
    // =========================================================

    private final String[] habitaciones = {

            "101",
            "102",
            "103",
            "201",
            "202",
            "203",
            "204"

    };


    // =========================================================
    // MEDIDAS
    // =========================================================

    private final int ANCHO_DIA = 65;

    private final int ANCHO_HABITACION = 85;


    // =========================================================
    // ON CREATE
    // =========================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_calendario_reservaciones
        );


        // Base de datos
        databaseHelper =
                new DatabaseHelper(this);


        // Obtener reservaciones
        reservaciones =
                databaseHelper.obtenerReservaciones();


        // Referencias XML
        layoutDias =
                findViewById(
                        R.id.layoutDias
                );

        layoutHabitaciones =
                findViewById(
                        R.id.layoutHabitaciones
                );

        layoutNombresHabitaciones =
                findViewById(
                        R.id.layoutNombresHabitaciones
                );


        txtMes =
                findViewById(
                        R.id.txtMes
                );


        btnMesAnterior =
                findViewById(
                        R.id.btnMesAnterior
                );

        btnMesSiguiente =
                findViewById(
                        R.id.btnMesSiguiente
                );

        btnCompartirMeses =
                findViewById(
                        R.id.btnCompartirMeses
                );


        // Scrolls
        scrollHorizontal =
                findViewById(
                        R.id.scrollHorizontal
                );

        scrollHabitaciones =
                findViewById(
                        R.id.scrollHabitaciones
                );

        scrollCeldas =
                findViewById(
                        R.id.scrollCeldas
                );


        // Fecha actual
        calendarioActual =
                Calendar.getInstance();


        // Mostrar calendario
        mostrarCalendario();


        // =====================================================
        // MES ANTERIOR
        // =====================================================

        btnMesAnterior.setOnClickListener(v -> {

            calendarioActual.add(
                    Calendar.MONTH,
                    -1
            );

            cargarReservaciones();

            mostrarCalendario();

        });


        // =====================================================
        // MES SIGUIENTE
        // =====================================================

        btnMesSiguiente.setOnClickListener(v -> {

            calendarioActual.add(
                    Calendar.MONTH,
                    1
            );

            cargarReservaciones();

            mostrarCalendario();

        });


        // =====================================================
        // COMPARTIR
        // =====================================================

        btnCompartirMeses.setOnClickListener(v -> {

            mostrarSelectorMeses();

        });


        // =====================================================
        // SINCRONIZAR SCROLL VERTICAL
        // =====================================================

        scrollHabitaciones.setOnScrollChangeListener(
                (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {

                    if (scrollCeldas.getScrollY() != scrollY) {

                        scrollCeldas.scrollTo(
                                0,
                                scrollY
                        );
                    }

                }
        );


        scrollCeldas.setOnScrollChangeListener(
                (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {

                    if (scrollHabitaciones.getScrollY() != scrollY) {

                        scrollHabitaciones.scrollTo(
                                0,
                                scrollY
                        );
                    }

                }
        );

    }


    // =========================================================
    // RECARGAR RESERVACIONES
    // =========================================================

    private void cargarReservaciones() {

        reservaciones =
                databaseHelper.obtenerReservaciones();

    }


    // =========================================================
    // MOSTRAR CALENDARIO
    // =========================================================

    private void mostrarCalendario() {

        layoutDias.removeAllViews();

        layoutHabitaciones.removeAllViews();

        layoutNombresHabitaciones.removeAllViews();


        // =====================================================
        // NOMBRE DEL MES
        // =====================================================

        SimpleDateFormat formatoMes =
                new SimpleDateFormat(
                        "MMMM yyyy",
                        new Locale(
                                "es",
                                "MX"
                        )
                );


        String mes =
                formatoMes.format(
                        calendarioActual.getTime()
                );


        mes =
                mes.substring(
                        0,
                        1
                ).toUpperCase()
                        + mes.substring(1);


        txtMes.setText(mes);


        // =====================================================
        // DIAS DEL MES
        // =====================================================

        int diasMes =
                calendarioActual.getActualMaximum(
                        Calendar.DAY_OF_MONTH
                );


        // Crear encabezado
        crearEncabezadoDias(
                diasMes
        );


        // Crear habitaciones
        crearHabitaciones(
                diasMes
        );

    }


    // =========================================================
    // ENCABEZADO DE DIAS
    // =========================================================

    private void crearEncabezadoDias(
            int diasMes) {


        for (
                int dia = 1;
                dia <= diasMes;
                dia++
        ) {


            Calendar fecha =
                    (Calendar)
                            calendarioActual.clone();


            fecha.set(
                    Calendar.DAY_OF_MONTH,
                    dia
            );


            // =================================================
            // DIA DE LA SEMANA
            // =================================================

            String nombreDia =
                    obtenerInicialDia(
                            fecha.get(
                                    Calendar.DAY_OF_WEEK
                            )
                    );


            // =================================================
            // TEXTVIEW DEL DIA
            // =================================================

            TextView diaView =
                    new TextView(this);


            diaView.setText(nombreDia);


            diaView.setTextColor(
                    Color.BLACK
            );


            diaView.setTextSize(
                    12
            );


            diaView.setGravity(
                    Gravity.CENTER
            );


            diaView.setTypeface(
                    null,
                    Typeface.BOLD
            );


            diaView.setBackgroundColor(
                    Color.rgb(
                            216,
                            184,
                            137
                    )
            );


            // =================================================
            // PARAMETROS
            // =================================================

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            ANCHO_DIA,
                            45
                    );


            params.setMargins(
                    1,
                    1,
                    1,
                    1
            );


            diaView.setLayoutParams(
                    params
            );


            layoutDias.addView(
                    diaView
            );

        }

    }


    // =========================================================
    // NOMBRE DEL DIA
    // =========================================================

    private String obtenerInicialDia(
            int diaSemana) {

        switch (diaSemana) {

            case Calendar.MONDAY:
                return "L";

            case Calendar.TUESDAY:
                return "M";

            case Calendar.WEDNESDAY:
                return "X";

            case Calendar.THURSDAY:
                return "J";

            case Calendar.FRIDAY:
                return "V";

            case Calendar.SATURDAY:
                return "S";

            case Calendar.SUNDAY:
                return "D";

            default:
                return "";

        }

    }


    // =========================================================
    // CREAR HABITACIONES
    // =========================================================

    private void crearHabitaciones(
            int diasMes) {


        for (
                String habitacion :
                habitaciones
        ) {


            // =================================================
            // NOMBRE HABITACION
            // =================================================

            TextView nombreHabitacion =
                    new TextView(this);


            nombreHabitacion.setText(
                    habitacion
            );


            nombreHabitacion.setTextColor(
                    Color.BLACK
            );


            nombreHabitacion.setTextSize(
                    14
            );


            nombreHabitacion.setGravity(
                    Gravity.CENTER
            );


            nombreHabitacion.setTypeface(
                    null,
                    Typeface.BOLD
            );


            nombreHabitacion.setBackgroundColor(
                    Color.rgb(
                            231,
                            214,
                            185
                    )
            );


            LinearLayout.LayoutParams
                    paramsHabitacion =
                    new LinearLayout.LayoutParams(
                            ANCHO_HABITACION,
                            55
                    );


            paramsHabitacion.setMargins(
                    1,
                    1,
                    1,
                    1
            );


            nombreHabitacion.setLayoutParams(
                    paramsHabitacion
            );


            layoutNombresHabitaciones.addView(
                    nombreHabitacion
            );


            // =================================================
            // FILA DE CELDAS
            // =================================================

            LinearLayout fila =
                    new LinearLayout(this);


            fila.setOrientation(
                    LinearLayout.HORIZONTAL
            );


            // =================================================
            // CREAR CADA DIA
            // =================================================

            for (
                    int dia = 1;
                    dia <= diasMes;
                    dia++
            ) {


                TextView celda =
                        crearCeldaDia(
                                habitacion,
                                dia
                        );


                fila.addView(
                        celda
                );

            }


            layoutHabitaciones.addView(
                    fila
            );

        }

    }


    // =========================================================
    // CREAR CELDA
    // =========================================================

    private TextView crearCeldaDia(
            String habitacion,
            int dia) {


        TextView celda =
                new TextView(this);


        celda.setText(
                String.valueOf(dia)
        );


        celda.setTextSize(
                13
        );


        celda.setGravity(
                Gravity.CENTER
        );


        celda.setTextColor(
                Color.BLACK
        );


        // =====================================================
        // BUSCAR RESERVACION
        // =====================================================

        Reservacion reservacion =
                obtenerReservacion(
                        habitacion,
                        dia
                );


        if (reservacion != null) {


            String tipoPago =
                    reservacion.getTipoPago();


            // Pago total
            if (
                    "Pago total".equals(
                            tipoPago
                    )
            ) {


                celda.setBackgroundColor(
                        Color.RED
                );


                celda.setTextColor(
                        Color.WHITE
                );

            }


            // Con anticipo
            else if (
                    "Con anticipo".equals(
                            tipoPago
                    )
            ) {


                celda.setBackgroundColor(
                        Color.YELLOW
                );


                celda.setTextColor(
                        Color.BLACK
                );

            }


            // Sin anticipo
            else if (
                    "Sin anticipo".equals(
                            tipoPago
                    )
            ) {


                celda.setBackgroundColor(
                        Color.BLUE
                );


                celda.setTextColor(
                        Color.WHITE
                );

            }


            else {


                celda.setBackgroundColor(
                        Color.LTGRAY
                );

            }

        }


        // =====================================================
        // DISPONIBLE
        // =====================================================

        else {


            celda.setBackgroundColor(
                    Color.rgb(
                            190,
                            230,
                            190
                    )
            );

        }


        // =====================================================
        // TAMAÑO
        // =====================================================

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        ANCHO_DIA,
                        55
                );


        params.setMargins(
                1,
                1,
                1,
                1
        );


        celda.setLayoutParams(
                params
        );


        // =====================================================
        // CLICK
        // =====================================================

        celda.setOnClickListener(v -> {

            mostrarInformacionHabitacion(
                    habitacion,
                    dia
            );

        });


        return celda;

    }


    // =========================================================
    // OBTENER RESERVACION
    // =========================================================

    private Reservacion obtenerReservacion(
            String habitacion,
            int dia) {


        Calendar fechaDia =
                (Calendar)
                        calendarioActual.clone();


        fechaDia.set(
                Calendar.DAY_OF_MONTH,
                dia
        );


        SimpleDateFormat formato =
                new SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                );


        String fechaSeleccionada =
                formato.format(
                        fechaDia.getTime()
                );


        try {


            Date fecha =
                    formato.parse(
                            fechaSeleccionada
                    );


            if (fecha == null) {

                return null;

            }


            for (
                    Reservacion reservacion :
                    reservaciones
            ) {


                // =================================================
                // COMPROBAR HABITACION
                // =================================================

                if (
                        !contieneHabitacion(
                                reservacion.getHabitaciones(),
                                habitacion
                        )
                ) {

                    continue;

                }


                Date inicio =
                        formato.parse(
                                reservacion.getFechaInicio()
                        );


                Date fin =
                        formato.parse(
                                reservacion.getFechaFin()
                        );


                if (
                        inicio != null &&
                                fin != null
                ) {


                    if (
                            fecha.compareTo(
                                    inicio
                            ) >= 0
                                    &&
                                    fecha.compareTo(
                                            fin
                                    ) <= 0
                    ) {


                        return reservacion;

                    }

                }

            }


        } catch (Exception e) {

            e.printStackTrace();

        }


        return null;

    }


    // =========================================================
    // COMPROBAR HABITACION
    // =========================================================

    private boolean contieneHabitacion(
            String habitacionesReservadas,
            String habitacion) {


        if (
                habitacionesReservadas == null
        ) {

            return false;

        }


        String[] lista =
                habitacionesReservadas.split(
                        ","
                );


        for (
                String h :
                lista
        ) {


            if (
                    h.trim().equals(
                            habitacion
                    )
            ) {

                return true;

            }

        }


        return false;

    }


    // =========================================================
    // INFORMACION DE RESERVACION
    // =========================================================

    private void mostrarInformacionHabitacion(
            String habitacion,
            int dia) {


        Calendar fechaDia =
                (Calendar)
                        calendarioActual.clone();


        fechaDia.set(
                Calendar.DAY_OF_MONTH,
                dia
        );


        SimpleDateFormat formato =
                new SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                );


        String fechaSeleccionada =
                formato.format(
                        fechaDia.getTime()
                );


        Reservacion reservacion =
                obtenerReservacion(
                        habitacion,
                        dia
                );


        // =====================================================
        // HABITACION LIBRE
        // =====================================================

        if (
                reservacion == null
        ) {


            new AlertDialog.Builder(this)

                    .setTitle(
                            "Habitación "
                                    + habitacion
                    )

                    .setMessage(
                            "Fecha: "
                                    + fechaSeleccionada
                                    + "\n\n"
                                    + "Habitación disponible."
                    )

                    .setPositiveButton(
                            "Cerrar",
                            null
                    )

                    .show();


            return;

        }


        // =====================================================
        // INFORMACION
        // =====================================================

        StringBuilder informacion =
                new StringBuilder();


        informacion.append(
                "👤 Cliente: "
        );


        informacion.append(
                reservacion.getNombre()
        );


        informacion.append(
                " "
        );


        informacion.append(
                reservacion.getApellidoPaterno()
        );


        informacion.append(
                " "
        );


        informacion.append(
                reservacion.getApellidoMaterno()
        );


        informacion.append(
                "\n\n"
        );


        informacion.append(
                "🛏 Habitación: "
        );


        informacion.append(
                habitacion
        );


        informacion.append(
                "\n"
        );


        informacion.append(
                "📅 Reservación: "
        );


        informacion.append(
                reservacion.getFechaInicio()
        );


        informacion.append(
                " - "
        );


        informacion.append(
                reservacion.getFechaFin()
        );


        informacion.append(
                "\n\n"
        );


        informacion.append(
                "💳 Pago: "
        );


        informacion.append(
                reservacion.getTipoPago()
        );


        informacion.append(
                "\n"
        );


        informacion.append(
                "💵 Costo: $"
        );


        informacion.append(
                reservacion.getCosto()
        );


        informacion.append(
                "\n\n"
        );


        informacion.append(
                "📢 Contacto: "
        );


        informacion.append(
                reservacion.getContacto()
        );


        // =====================================================
        // DIALOGO
        // =====================================================

        new AlertDialog.Builder(this)

                .setTitle(
                        "Reservación - Habitación "
                                + habitacion
                )

                .setMessage(
                        informacion.toString()
                )

                .setPositiveButton(
                        "Cerrar",
                        null
                )

                .show();

    }


    // =========================================================
    // SELECTOR DE MESES
    // =========================================================

    private void mostrarSelectorMeses() {


        final ArrayList<String> meses =
                new ArrayList<>();


        final ArrayList<Integer>
                mesesNumero =
                new ArrayList<>();


        Calendar fechaActual =
                Calendar.getInstance();


        Calendar inicio =
                (Calendar)
                        fechaActual.clone();


        inicio.add(
                Calendar.MONTH,
                -6
        );


        for (
                int i = 0;
                i < 12;
                i++
        ) {


            Calendar fecha =
                    (Calendar)
                            inicio.clone();


            fecha.add(
                    Calendar.MONTH,
                    i
            );


            SimpleDateFormat formato =
                    new SimpleDateFormat(
                            "MMMM yyyy",
                            new Locale(
                                    "es",
                                    "MX"
                            )
                    );


            String nombreMes =
                    formato.format(
                            fecha.getTime()
                    );


            nombreMes =
                    nombreMes.substring(
                            0,
                            1
                    ).toUpperCase()
                            + nombreMes.substring(1);


            meses.add(
                    nombreMes
            );


            int valorMes =
                    fecha.get(
                            Calendar.YEAR
                    ) * 100
                            + fecha.get(
                            Calendar.MONTH
                    );


            mesesNumero.add(
                    valorMes
            );

        }


        boolean[] seleccionados =
                new boolean[
                        meses.size()
                        ];


        AlertDialog.Builder builder =
                new AlertDialog.Builder(
                        this
                );


        builder.setTitle(
                "Selecciona los meses que deseas compartir"
        );


        builder.setMultiChoiceItems(

                meses.toArray(
                        new String[0]
                ),

                seleccionados,

                (dialog, which, isChecked) -> {

                    seleccionados[which] =
                            isChecked;

                }

        );


        builder.setNegativeButton(
                "Cancelar",
                null
        );


        builder.setPositiveButton(

                "COMPARTIR",

                (dialog, which) -> {


                    ArrayList<Integer>
                            mesesSeleccionados =
                            new ArrayList<>();


                    for (
                            int i = 0;
                            i < seleccionados.length;
                            i++
                    ) {


                        if (
                                seleccionados[i]
                        ) {


                            mesesSeleccionados.add(
                                    mesesNumero.get(i)
                            );

                        }

                    }


                    if (
                            mesesSeleccionados.isEmpty()
                    ) {


                        Toast.makeText(

                                this,

                                "Selecciona al menos un mes",

                                Toast.LENGTH_SHORT

                        ).show();


                        return;

                    }


                    compartirMeses(
                            mesesSeleccionados
                    );

                }

        );


        builder.show();

    }


    // =========================================================
    // COMPARTIR MESES
    // =========================================================

    private void compartirMeses(
            ArrayList<Integer>
                    mesesSeleccionados) {


        StringBuilder calendarioICS =
                new StringBuilder();


        calendarioICS.append(
                "BEGIN:VCALENDAR\r\n"
        );


        calendarioICS.append(
                "VERSION:2.0\r\n"
        );


        calendarioICS.append(
                "PRODID:-//Beit Shalom//Reservaciones//ES\r\n"
        );


        calendarioICS.append(
                "CALSCALE:GREGORIAN\r\n"
        );


        calendarioICS.append(
                "METHOD:PUBLISH\r\n"
        );


        SimpleDateFormat formatoFecha =
                new SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                );


        SimpleDateFormat formatoICS =
                new SimpleDateFormat(
                        "yyyyMMdd",
                        Locale.getDefault()
                );


        boolean encontroAlguna =
                false;


        for (
                Reservacion reservacion :
                reservaciones
        ) {


            try {


                Date inicio =
                        formatoFecha.parse(
                                reservacion.getFechaInicio()
                        );


                Date fin =
                        formatoFecha.parse(
                                reservacion.getFechaFin()
                        );


                if (
                        inicio != null &&
                                fin != null
                ) {


                    Calendar cal =
                            Calendar.getInstance();


                    cal.setTime(
                            inicio
                    );


                    int valorMesReservacion =
                            cal.get(
                                    Calendar.YEAR
                            ) * 100
                                    + cal.get(
                                    Calendar.MONTH
                            );


                    if (
                            mesesSeleccionados.contains(
                                    valorMesReservacion
                            )
                    ) {


                        encontroAlguna =
                                true;


                        String fechaInicioStr =
                                formatoICS.format(
                                        inicio
                                );


                        Calendar calFin =
                                Calendar.getInstance();


                        calFin.setTime(
                                fin
                        );


                        calFin.add(
                                Calendar.DAY_OF_MONTH,
                                1
                        );


                        String fechaFinStr =
                                formatoICS.format(
                                        calFin.getTime()
                                );


                        calendarioICS.append(
                                "BEGIN:VEVENT\r\n"
                        );


                        calendarioICS.append(
                                "UID:"
                        );


                        calendarioICS.append(
                                reservacion.getId()
                        );


                        calendarioICS.append(
                                "@beitshalom\r\n"
                        );


                        calendarioICS.append(
                                "DTSTART;VALUE=DATE:"
                        );


                        calendarioICS.append(
                                fechaInicioStr
                        );


                        calendarioICS.append(
                                "\r\n"
                        );


                        calendarioICS.append(
                                "DTEND;VALUE=DATE:"
                        );


                        calendarioICS.append(
                                fechaFinStr
                        );


                        calendarioICS.append(
                                "\r\n"
                        );


                        String nombre =
                                reservacion.getNombre()
                                        + " "
                                        + reservacion.getApellidoPaterno()
                                        + " "
                                        + reservacion.getApellidoMaterno();


                        calendarioICS.append(
                                "SUMMARY:"
                        );


                        calendarioICS.append(
                                escaparICS(
                                        "Reservación - "
                                                + nombre
                                )
                        );


                        calendarioICS.append(
                                "\r\n"
                        );


                        String descripcion =
                                "Habitaciones: "
                                        + reservacion.getHabitaciones()
                                        + "\\n"
                                        + "Pago: "
                                        + reservacion.getTipoPago()
                                        + "\\n"
                                        + "Costo: $"
                                        + reservacion.getCosto()
                                        + "\\n"
                                        + "Contacto: "
                                        + reservacion.getContacto();


                        calendarioICS.append(
                                "DESCRIPTION:"
                        );


                        calendarioICS.append(
                                escaparICS(
                                        descripcion
                                )
                        );


                        calendarioICS.append(
                                "\r\n"
                        );


                        calendarioICS.append(
                                "END:VEVENT\r\n"
                        );

                    }

                }


            } catch (Exception e) {

                e.printStackTrace();

            }

        }


        calendarioICS.append(
                "END:VCALENDAR\r\n"
        );


        if (
                !encontroAlguna
        ) {


            Toast.makeText(

                    this,

                    "No hay reservaciones en los meses seleccionados",

                    Toast.LENGTH_SHORT

            ).show();


            return;

        }


        // =====================================================
        // CREAR ARCHIVO
        // =====================================================

        try {


            File carpeta =
                    new File(
                            getCacheDir(),
                            "calendario"
                    );


            if (
                    !carpeta.exists()
            ) {

                carpeta.mkdirs();

            }


            File archivoICS =
                    new File(
                            carpeta,
                            "reservaciones_seleccionadas.ics"
                    );


            java.io.FileOutputStream salida =
                    new java.io.FileOutputStream(
                            archivoICS
                    );


            salida.write(
                    calendarioICS.toString()
                            .getBytes(
                                    java.nio.charset.StandardCharsets.UTF_8
                            )
            );


            salida.close();


            Uri uri =
                    FileProvider.getUriForFile(

                            this,

                            getPackageName()
                                    + ".fileprovider",

                            archivoICS

                    );


            Intent compartirIntent =
                    new Intent(
                            Intent.ACTION_SEND
                    );


            compartirIntent.setType(
                    "text/calendar"
            );


            compartirIntent.putExtra(

                    Intent.EXTRA_SUBJECT,

                    "Calendario de Reservaciones (.ics)"

            );


            compartirIntent.putExtra(

                    Intent.EXTRA_STREAM,

                    uri

            );


            compartirIntent.addFlags(

                    Intent.FLAG_GRANT_READ_URI_PERMISSION

            );


            startActivity(

                    Intent.createChooser(

                            compartirIntent,

                            "Compartir archivo de calendario"

                    )

            );


        } catch (Exception e) {


            e.printStackTrace();


            Toast.makeText(

                    this,

                    "Error al generar el archivo ICS",

                    Toast.LENGTH_SHORT

            ).show();

        }

    }


    // =========================================================
    // ESCAPAR ICS
    // =========================================================

    private String escaparICS(
            String texto) {


        if (
                texto == null
        ) {

            return "";

        }


        return texto

                .replace(
                        "\\",
                        "\\\\"
                )

                .replace(
                        ";",
                        "\\;"
                )

                .replace(
                        ",",
                        "\\,"
                )

                .replace(
                        "\n",
                        "\\n"
                )

                .replace(
                        "\r",
                        ""
                );

    }

}

