package com.beit.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Beit.db";
    private static final int DATABASE_VERSION = 3;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // ============================================================
    // CREAR RESERVACIÓN
    // ============================================================

    public boolean insertarCliente(
            String nombre,
            String apellidoPaterno,
            String apellidoMaterno,
            int numeroPersonas,
            String habitaciones,
            String tipoPago,
            double costo,
            String fechaInicio,
            String fechaFin,
            String contacto) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues valores = new ContentValues();

        valores.put("nombre", nombre);
        valores.put("apellidoPaterno", apellidoPaterno);
        valores.put("apellidoMaterno", apellidoMaterno);
        valores.put("numeroPersonas", numeroPersonas);
        valores.put("habitaciones", habitaciones);
        valores.put("tipoPago", tipoPago);
        valores.put("costo", costo);
        valores.put("fechaInicio", fechaInicio);
        valores.put("fechaFin", fechaFin);
        valores.put("contacto", contacto);

        long resultado = db.insert(
                "clientes",
                null,
                valores
        );

        return resultado != -1;
    }

    // ============================================================
    // CREAR TABLA
    // ============================================================

    @Override
    public void onCreate(SQLiteDatabase db) {

        String crearTabla =
                "CREATE TABLE clientes (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "nombre TEXT, " +
                        "apellidoPaterno TEXT, " +
                        "apellidoMaterno TEXT, " +
                        "numeroPersonas INTEGER, " +
                        "habitaciones TEXT, " +
                        "tipoPago TEXT, " +
                        "costo REAL, " +
                        "fechaInicio TEXT, " +
                        "fechaFin TEXT, " +
                        "contacto TEXT" +
                        ")";

        db.execSQL(crearTabla);
    }

    // ============================================================
    // ACTUALIZAR BASE DE DATOS
    // ============================================================

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS clientes");

        onCreate(db);
    }

    // ============================================================
    // OBTENER TODOS LOS REGISTROS
    // ============================================================

    public Cursor obtenerNombres() {

        SQLiteDatabase db = this.getReadableDatabase();

        String consulta =
                "SELECT * FROM clientes";

        return db.rawQuery(
                consulta,
                null
        );
    }

    // ============================================================
    // OBTENER RESERVACIONES
    // ============================================================

    public ArrayList<Reservacion> obtenerReservaciones() {

        ArrayList<Reservacion> lista =
                new ArrayList<>();

        SQLiteDatabase db =
                this.getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT * FROM clientes",
                        null
                );

        while (cursor.moveToNext()) {

            Log.d(
                    "BD",
                    "Nombre: " +
                            cursor.getString(1)
            );

            Reservacion reservacion =
                    new Reservacion(
                            cursor.getInt(0),
                            cursor.getString(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getInt(4),
                            cursor.getString(5),
                            cursor.getString(6),
                            cursor.getDouble(7),
                            cursor.getString(8),
                            cursor.getString(9),
                            cursor.getString(10)
                    );

            lista.add(reservacion);
        }

        cursor.close();

        return lista;
    }

    // ============================================================
    // COMPROBAR DISPONIBILIDAD AL CREAR
    // ============================================================

    public boolean habitacionesDisponibles(
            String habitacionesNuevas,
            String fechaInicioNueva,
            String fechaFinNueva) {

        SQLiteDatabase db =
                this.getReadableDatabase();

        SimpleDateFormat formato =
                new SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                );

        formato.setLenient(false);

        try {

            Date inicioNueva =
                    formato.parse(fechaInicioNueva);

            Date finNueva =
                    formato.parse(fechaFinNueva);

            if (inicioNueva == null ||
                    finNueva == null) {

                return false;
            }

            if (finNueva.before(inicioNueva)) {

                return false;
            }

            Cursor cursor =
                    db.rawQuery(
                            "SELECT habitaciones, fechaInicio, fechaFin " +
                                    "FROM clientes",
                            null
                    );

            while (cursor.moveToNext()) {

                String habitacionesGuardadas =
                        cursor.getString(0);

                String fechaInicioGuardada =
                        cursor.getString(1);

                String fechaFinGuardada =
                        cursor.getString(2);

                if (habitacionesGuardadas == null ||
                        fechaInicioGuardada == null ||
                        fechaFinGuardada == null) {

                    continue;
                }

                Date inicioGuardado =
                        formato.parse(fechaInicioGuardada);

                Date finGuardado =
                        formato.parse(fechaFinGuardada);

                if (inicioGuardado == null ||
                        finGuardado == null) {

                    continue;
                }

                boolean fechasChocan =
                        !inicioNueva.after(finGuardado) &&
                                !finNueva.before(inicioGuardado);

                if (fechasChocan) {

                    String[] nuevas =
                            habitacionesNuevas.split(",");

                    String[] guardadas =
                            habitacionesGuardadas.split(",");

                    for (String nueva : nuevas) {

                        nueva = nueva.trim();

                        for (String guardada : guardadas) {

                            guardada = guardada.trim();

                            if (nueva.equals(guardada)) {

                                cursor.close();

                                return false;
                            }
                        }
                    }
                }
            }

            cursor.close();

            return true;

        } catch (ParseException e) {

            e.printStackTrace();

            return false;
        }
    }

    // ============================================================
    // COMPROBAR DISPONIBILIDAD AL EDITAR
    // ============================================================

    public boolean habitacionesDisponiblesEditar(
            int idReservacion,
            String habitacionesNuevas,
            String fechaInicioNueva,
            String fechaFinNueva) {

        SQLiteDatabase db =
                this.getReadableDatabase();

        SimpleDateFormat formato =
                new SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                );

        formato.setLenient(false);

        try {

            // ----------------------------------------------------
            // Convertir las nuevas fechas
            // ----------------------------------------------------

            Date inicioNueva =
                    formato.parse(fechaInicioNueva);

            Date finNueva =
                    formato.parse(fechaFinNueva);

            if (inicioNueva == null ||
                    finNueva == null) {

                return false;
            }

            // ----------------------------------------------------
            // Verificar que las fechas sean correctas
            // ----------------------------------------------------

            if (finNueva.before(inicioNueva)) {

                return false;
            }

            // ----------------------------------------------------
            // IMPORTANTE:
            // No consultar la reservación que estamos editando.
            // ----------------------------------------------------

            Cursor cursor =
                    db.rawQuery(
                            "SELECT id, habitaciones, fechaInicio, fechaFin " +
                                    "FROM clientes " +
                                    "WHERE id != ?",
                            new String[]{
                                    String.valueOf(idReservacion)
                            }
                    );

            while (cursor.moveToNext()) {

                String habitacionesGuardadas =
                        cursor.getString(1);

                String fechaInicioGuardada =
                        cursor.getString(2);

                String fechaFinGuardada =
                        cursor.getString(3);

                if (habitacionesGuardadas == null ||
                        fechaInicioGuardada == null ||
                        fechaFinGuardada == null) {

                    continue;
                }

                // ------------------------------------------------
                // Convertir fechas guardadas
                // ------------------------------------------------

                Date inicioGuardado =
                        formato.parse(fechaInicioGuardada);

                Date finGuardado =
                        formato.parse(fechaFinGuardada);

                if (inicioGuardado == null ||
                        finGuardado == null) {

                    continue;
                }

                // ------------------------------------------------
                // Comprobar si las fechas se cruzan
                // ------------------------------------------------

                boolean fechasChocan =
                        !inicioNueva.after(finGuardado) &&
                                !finNueva.before(inicioGuardado);

                if (fechasChocan) {

                    String[] nuevas =
                            habitacionesNuevas.split(",");

                    String[] guardadas =
                            habitacionesGuardadas.split(",");

                    // --------------------------------------------
                    // Comprobar habitaciones
                    // --------------------------------------------

                    for (String nueva : nuevas) {

                        nueva = nueva.trim();

                        if (nueva.isEmpty()) {
                            continue;
                        }

                        for (String guardada : guardadas) {

                            guardada = guardada.trim();

                            if (guardada.isEmpty()) {
                                continue;
                            }

                            if (nueva.equals(guardada)) {

                                cursor.close();

                                return false;
                            }
                        }
                    }
                }
            }

            cursor.close();

            return true;

        } catch (ParseException e) {

            Log.e(
                    "BD",
                    "Error al convertir las fechas",
                    e
            );

            return false;
        }
    }

    // ============================================================
    // ELIMINAR RESERVACIÓN
    // ============================================================

    public boolean eliminarReservacion(int id) {

        SQLiteDatabase db =
                this.getWritableDatabase();

        int filas =
                db.delete(
                        "clientes",
                        "id = ?",
                        new String[]{
                                String.valueOf(id)
                        }
                );

        return filas > 0;
    }

    // ============================================================
    // ACTUALIZAR RESERVACIÓN
    // ============================================================

    public boolean actualizarReservacion(
            int id,
            String nombre,
            String apellidoPaterno,
            String apellidoMaterno,
            int numeroPersonas,
            String habitaciones,
            String tipoPago,
            double costo,
            String fechaInicio,
            String fechaFin,
            String contacto) {

        SQLiteDatabase db =
                this.getWritableDatabase();

        ContentValues valores =
                new ContentValues();

        valores.put("nombre", nombre);
        valores.put(
                "apellidoPaterno",
                apellidoPaterno
        );
        valores.put(
                "apellidoMaterno",
                apellidoMaterno
        );
        valores.put(
                "numeroPersonas",
                numeroPersonas
        );
        valores.put(
                "habitaciones",
                habitaciones
        );
        valores.put(
                "tipoPago",
                tipoPago
        );
        valores.put(
                "costo",
                costo
        );
        valores.put(
                "fechaInicio",
                fechaInicio
        );
        valores.put(
                "fechaFin",
                fechaFin
        );
        valores.put(
                "contacto",
                contacto
        );

        int resultado =
                db.update(
                        "clientes",
                        valores,
                        "id = ?",
                        new String[]{
                                String.valueOf(id)
                        }
                );

        return resultado > 0;
    }
}