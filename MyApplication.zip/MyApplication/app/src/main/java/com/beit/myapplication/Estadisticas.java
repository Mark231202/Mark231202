package com.beit.myapplication;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Estadisticas extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private ArrayList<Reservacion> reservaciones;

    private TextView txtGananciaTotal;
    private TextView txtEstadisticasMeses;
    private TextView txtMediosContacto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        txtGananciaTotal = findViewById(R.id.txtGananciaTotal);
        txtEstadisticasMeses = findViewById(R.id.txtEstadisticasMeses);
        txtMediosContacto = findViewById(R.id.txtMediosContacto);

        databaseHelper = new DatabaseHelper(this);
        reservaciones = databaseHelper.obtenerReservaciones();

        calcularEstadisticas();
    }

    private void calcularEstadisticas() {
        if (reservaciones == null || reservaciones.isEmpty()) {
            txtGananciaTotal.setText("$0.00");
            txtEstadisticasMeses.setText("No hay reservaciones registradas.");
            txtMediosContacto.setText("No hay datos de contacto disponibles.");
            return;
        }

        double gananciaTotal = 0.0;

        // Estructuras para acumular estadísticas por mes
        Map<String, Double> ingresosPorMes = new HashMap<>();
        Map<String, Integer> conteoPorMes = new HashMap<>();

        // Estructura para acumular medios de contacto
        Map<String, Integer> conteoContacto = new HashMap<>();

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        SimpleDateFormat formatoMesAnio = new SimpleDateFormat("MMMM yyyy", new Locale("es", "MX"));

        for (Reservacion res : reservaciones) {

            // 1. Sumar costo/ganancia
            // CÓDIGO CORREGIDO:
            double costo = res.getCosto(); // Si getCosto() devuelve double directamente
            gananciaTotal += costo;

            // 2. Procesar fecha para agrupar por Mes/Año
            try {
                java.util.Date fechaInicio = formatoFecha.parse(res.getFechaInicio());
                if (fechaInicio != null) {
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(fechaInicio);

                    String llaveMes = formatoMesAnio.format(cal.getTime());
                    llaveMes = llaveMes.substring(0, 1).toUpperCase() + llaveMes.substring(1);

                    // Acumular dinero por mes
                    double ingresoActual = ingresosPorMes.containsKey(llaveMes) ? ingresosPorMes.get(llaveMes) : 0.0;
                    ingresosPorMes.put(llaveMes, ingresoActual + costo);

                    // Acumular cantidad de reservas por mes
                    int reservasActuales = conteoPorMes.containsKey(llaveMes) ? conteoPorMes.get(llaveMes) : 0;
                    conteoPorMes.put(llaveMes, reservasActuales + 1);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 3. Procesar medio de contacto
            String contacto = res.getContacto();
            if (contacto != null && !contacto.trim().isEmpty()) {
                contacto = contacto.trim();
                int conteo = conteoContacto.containsKey(contacto) ? conteoContacto.get(contacto) : 0;
                conteoContacto.put(contacto, conteo + 1);
            }
        }

        // --- RENDERIZAR RESULTADOS ---

        // Ganancia Total
        txtGananciaTotal.setText(String.format(Locale.getDefault(), "$%.2f", gananciaTotal));

        // Meses con más reservaciones e ingresos
        StringBuilder builderMeses = new StringBuilder();
        for (String mes : conteoPorMes.keySet()) {
            int numReservas = conteoPorMes.get(mes);
            double totalDinero = ingresosPorMes.get(mes);

            builderMeses.append("• ").append(mes).append(":\n")
                    .append("   - Reservaciones: ").append(numReservas).append("\n")
                    .append("   - Ingreso: $").append(String.format(Locale.getDefault(), "%.2f", totalDinero)).append("\n\n");
        }
        txtEstadisticasMeses.setText(builderMeses.toString().trim());

        // Medios de contacto
        StringBuilder builderContacto = new StringBuilder();
        for (Map.Entry<String, Integer> entry : conteoContacto.entrySet()) {
            builderContacto.append("• ").append(entry.getKey())
                    .append(": ").append(entry.getValue()).append(" reservación(es)\n");
        }

        if (builderContacto.length() == 0) {
            txtMediosContacto.setText("Sin registros de medios de contacto.");
        } else {
            txtMediosContacto.setText(builderContacto.toString().trim());
        }
    }
}