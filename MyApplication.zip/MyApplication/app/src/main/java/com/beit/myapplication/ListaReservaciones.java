package com.beit.myapplication;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.ListView;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;

import java.util.ArrayList;

public class ListaReservaciones extends AppCompatActivity {

    private EditText edtBuscar;
    private DatabaseHelper databaseHelper;
    private ListView listaReservaciones;

    private ArrayList<Reservacion> lista;
    private ArrayList<Reservacion> listaCompleta;

    private ReservacionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista_reservaciones);

        databaseHelper = new DatabaseHelper(this);

        listaReservaciones = findViewById(R.id.listaReservaciones);
        edtBuscar = findViewById(R.id.edtBuscar);

        listaCompleta = databaseHelper.obtenerReservaciones();

        lista = new ArrayList<>(listaCompleta);

        adapter = new ReservacionAdapter(
                this,
                lista
        );

        listaReservaciones.setAdapter(adapter);

        edtBuscar.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count) {

                String texto = s.toString()
                        .toLowerCase()
                        .trim();

                lista.clear();

                for (Reservacion reservacion : listaCompleta) {

                    String nombreCompleto =
                            reservacion.getNombre() + " " +
                                    reservacion.getApellidoPaterno() + " " +
                                    reservacion.getApellidoMaterno();

                    if (nombreCompleto
                            .toLowerCase()
                            .contains(texto)) {

                        lista.add(reservacion);
                    }
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    @Override
    protected void onResume() {

        super.onResume();

        listaCompleta.clear();
        listaCompleta.addAll(
                databaseHelper.obtenerReservaciones()
        );

        String texto = edtBuscar
                .getText()
                .toString()
                .toLowerCase()
                .trim();

        lista.clear();

        for (Reservacion reservacion : listaCompleta) {

            String nombreCompleto =
                    reservacion.getNombre() + " " +
                            reservacion.getApellidoPaterno() + " " +
                            reservacion.getApellidoMaterno();

            if (nombreCompleto
                    .toLowerCase()
                    .contains(texto)) {

                lista.add(reservacion);
            }
        }

        adapter.notifyDataSetChanged();
    }
}