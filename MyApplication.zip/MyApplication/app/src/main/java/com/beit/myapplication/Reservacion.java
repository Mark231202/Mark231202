package com.beit.myapplication;

public class Reservacion {

    private int id;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private int numeroPersonas;
    private String habitaciones;
    private String tipoPago;
    private double costo;
    private String fechaInicio;
    private String fechaFin;
    private String contacto;

    public Reservacion(
            int id,
            String nombre,
            String apellidoPaterno,
            String apellidoMaterno,
            int numeroPersonas,
            String habitaciones,
            String tipoPago,
            double costo,
            String fechaInicio,
            String fechaFin,
            String contacto
    ) {
        this.id = id;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.numeroPersonas = numeroPersonas;
        this.habitaciones = habitaciones;
        this.tipoPago = tipoPago;
        this.costo = costo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.contacto = contacto;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public int getNumeroPersonas() {
        return numeroPersonas;
    }

    public String getHabitaciones() {
        return habitaciones;
    }

    public String getTipoPago() {
        return tipoPago;
    }

    public double getCosto() {
        return costo;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public String getContacto() {
        return contacto;
    }
}