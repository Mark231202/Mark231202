package com.beit.myapplication;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button registrar = findViewById(R.id.btnRegistrar);
        Button mostrar = findViewById(R.id.btnReservaciones);
        Button fecha= findViewById(R.id.btnFechas);
        Button Rendimiento= findViewById(R.id.btnestadisticas);
        //*************Registro************
        registrar.setOnClickListener(v -> {
            Intent intent = new Intent( MainActivity.this, Registro.class);
            startActivity(intent);
        });
        //*************Mostrar************
        mostrar.setOnClickListener(v ->{
            Intent intent1= new Intent(MainActivity.this, ListaReservaciones.class);
            startActivity(intent1);
        });

        fecha.setOnClickListener(v ->{
            Intent intent2= new Intent(MainActivity.this, CalendarioReservaciones.class);
            startActivity(intent2);
        });
        Rendimiento.setOnClickListener(v ->{
            Intent intent3= new Intent(MainActivity.this, Estadisticas.class);
            startActivity(intent3);
        });


    }
}