package com.beit.myapplication;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Modificar extends AppCompatActivity {

    private int idReservacion;

    private RadioGroup rgContacto;

    private RadioButton rbFacebook;
    private RadioButton rbInstagram;
    private RadioButton rbBooking;
    private RadioButton rbAirbnb;

    private EditText fechainEdit;
    private EditText fechafinEdit;

    private Calendar fechaInicioSeleccionada;

    private EditText costoEdit;
    private EditText nameEdit;
    private EditText apepaEdit;
    private EditText apemaEdit;

    private Button btnRegistrar;

    private EditText cuartoSpinner;

    private final String[] habitaciones = {
            "101",
            "102",
            "103",
            "201",
            "202",
            "203",
            "204"
    };

    private final int[] precios = {
            1600,
            1600,
            800,
            850,
            1200,
            650,
            650
    };

    private final boolean[] seleccionados =
            new boolean[habitaciones.length];

    private double totalHabitaciones = 0;

    private EditText personaEdit;

    private DatabaseHelper databaseHelper;

    private Spinner spPago;

    private boolean cargandoDatos = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_modificar);

        // ========================================================
        // REFERENCIAS DE LA INTERFAZ
        // ========================================================

        nameEdit = findViewById(R.id.nameEdit);
        apepaEdit = findViewById(R.id.apepaEdit);
        apemaEdit = findViewById(R.id.apemaEdit);
        personaEdit = findViewById(R.id.personaEdit);

        btnRegistrar = findViewById(R.id.btnRegistrar);

        cuartoSpinner = findViewById(R.id.cuartoSpinner);

        costoEdit = findViewById(R.id.costoEdit);

        spPago = findViewById(R.id.spPago);

        fechainEdit = findViewById(R.id.fechainEdit);
        fechafinEdit = findViewById(R.id.fechafinEdit);

        rgContacto = findViewById(R.id.rgContacto);

        rbFacebook = findViewById(R.id.rbFacebook);
        rbInstagram = findViewById(R.id.rbInstagram);
        rbBooking = findViewById(R.id.rbBooking);
        rbAirbnb = findViewById(R.id.rbAirbnb);

        databaseHelper = new DatabaseHelper(this);

        // ========================================================
        // OBTENER DATOS DE LA RESERVACIÓN
        // ========================================================

        Intent intent = getIntent();

        idReservacion = intent.getIntExtra("id", -1);

        nameEdit.setText(
                intent.getStringExtra("nombre")
        );

        apepaEdit.setText(
                intent.getStringExtra("apellidoPaterno")
        );

        apemaEdit.setText(
                intent.getStringExtra("apellidoMaterno")
        );

        personaEdit.setText(
                String.valueOf(
                        intent.getIntExtra(
                                "numeroPersonas",
                                0
                        )
                )
        );

        // ========================================================
        // CARGAR HABITACIONES
        // ========================================================

        String habitacionesActuales =
                intent.getStringExtra("habitaciones");

        cuartoSpinner.setText(
                habitacionesActuales
        );

        cargarHabitacionesSeleccionadas(
                habitacionesActuales
        );

        // ========================================================
        // CARGAR COSTO
        // ========================================================

        costoEdit.setText(
                String.valueOf(
                        intent.getDoubleExtra(
                                "costo",
                                0
                        )
                )
        );

        totalHabitaciones =
                intent.getDoubleExtra(
                        "costo",
                        0
                );

        // ========================================================
        // CARGAR FECHAS
        // ========================================================

        String fechaInicioCargada =
                intent.getStringExtra("fechaInicio");

        String fechaFinCargada =
                intent.getStringExtra("fechaFin");

        fechainEdit.setText(
                fechaInicioCargada
        );

        fechafinEdit.setText(
                fechaFinCargada
        );

        // Cargar la fecha inicial en Calendar
        cargarFechaInicio(
                fechaInicioCargada
        );

        // ========================================================
        // CARGAR CONTACTO
        // ========================================================

        String contactoIntent =
                intent.getStringExtra("contacto");

        if ("Facebook".equals(contactoIntent)) {

            rbFacebook.setChecked(true);

        } else if ("Instagram".equals(contactoIntent)) {

            rbInstagram.setChecked(true);

        } else if ("Booking".equals(contactoIntent)) {

            rbBooking.setChecked(true);

        } else if ("Airbnb".equals(contactoIntent)) {

            rbAirbnb.setChecked(true);
        }

        // ========================================================
        // CONFIGURAR BOTÓN
        // ========================================================

        btnRegistrar.setText("Actualizar");

        // ========================================================
        // SELECTOR DE HABITACIONES
        // ========================================================

        cuartoSpinner.setOnClickListener(
                v -> mostrarHabitaciones()
        );

        // ========================================================
        // SELECTOR DE FECHA INICIAL
        // ========================================================

        fechainEdit.setOnClickListener(
                v -> mostrarCalendarioInicio()
        );

        // ========================================================
        // SELECTOR DE FECHA FINAL
        // ========================================================

        fechafinEdit.setOnClickListener(
                v -> mostrarCalendarioFin()
        );

        // ========================================================
        // TIPOS DE PAGO
        // ========================================================

        String[] tiposPago = {
                "Pago total",
                "Con anticipo",
                "Sin anticipo"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        tiposPago
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spPago.setAdapter(adapter);

        String tipoPagoIntent =
                intent.getStringExtra("tipoPago");

        int posicion =
                adapter.getPosition(
                        tipoPagoIntent
                );

        if (posicion < 0) {
            posicion = 0;
        }

        cargandoDatos = false;

        spPago.setSelection(posicion);

        // ========================================================
        // EVENTO DEL TIPO DE PAGO
        // ========================================================

        spPago.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            android.view.View view,
                            int position,
                            long id) {

                        if (cargandoDatos) {
                            return;
                        }

                        String tipoPago =
                                parent
                                        .getItemAtPosition(position)
                                        .toString();

                        if (tipoPago.equals("Pago total")) {

                            costoEdit.setText(
                                    String.valueOf(
                                            totalHabitaciones
                                    )
                            );

                            costoEdit.setFocusable(false);
                            costoEdit.setFocusableInTouchMode(false);
                            costoEdit.setClickable(false);

                        } else if (tipoPago.equals("Con anticipo")) {

                            if (costoEdit
                                    .getText()
                                    .toString()
                                    .equals("0")) {

                                costoEdit.setText("");
                            }

                            costoEdit.setFocusable(true);
                            costoEdit.setFocusableInTouchMode(true);
                            costoEdit.setClickable(true);

                        } else if (tipoPago.equals("Sin anticipo")) {

                            costoEdit.setText("0");

                            costoEdit.setFocusable(false);
                            costoEdit.setFocusableInTouchMode(false);
                            costoEdit.setClickable(false);
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent) {
                    }
                }
        );

        // ========================================================
        // BOTÓN ACTUALIZAR
        // ========================================================

        btnRegistrar.setOnClickListener(v -> {

            // ----------------------------------------------------
            // Validar número de personas
            // ----------------------------------------------------

            if (personaEdit
                    .getText()
                    .toString()
                    .trim()
                    .isEmpty()) {

                Toast.makeText(
                        this,
                        "Ingrese el número de personas",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            String nombre =
                    nameEdit
                            .getText()
                            .toString()
                            .trim();

            String apellidoPaterno =
                    apepaEdit
                            .getText()
                            .toString()
                            .trim();

            String apellidoMaterno =
                    apemaEdit
                            .getText()
                            .toString()
                            .trim();

            int numeroPersonas;

            try {

                numeroPersonas =
                        Integer.parseInt(
                                personaEdit
                                        .getText()
                                        .toString()
                                        .trim()
                        );

            } catch (NumberFormatException e) {

                Toast.makeText(
                        this,
                        "Número de personas inválido",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // ----------------------------------------------------
            // Habitaciones
            // ----------------------------------------------------

            String habitacionesSeleccionadas =
                    cuartoSpinner
                            .getText()
                            .toString()
                            .trim();

            if (habitacionesSeleccionadas.isEmpty()) {

                Toast.makeText(
                        this,
                        "Seleccione al menos una habitación",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // ----------------------------------------------------
            // Tipo de pago
            // ----------------------------------------------------

            String tipoPago =
                    spPago
                            .getSelectedItem()
                            .toString();

            // ----------------------------------------------------
            // Costo
            // ----------------------------------------------------

            double costo = 0;

            if (!costoEdit
                    .getText()
                    .toString()
                    .trim()
                    .isEmpty()) {

                try {

                    costo =
                            Double.parseDouble(
                                    costoEdit
                                            .getText()
                                            .toString()
                                            .trim()
                            );

                } catch (NumberFormatException e) {

                    Toast.makeText(
                            this,
                            "Costo inválido",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }
            }

            // ----------------------------------------------------
            // Fechas NUEVAS
            // ----------------------------------------------------

            String fechaInicioNueva =
                    fechainEdit
                            .getText()
                            .toString()
                            .trim();

            String fechaFinNueva =
                    fechafinEdit
                            .getText()
                            .toString()
                            .trim();

            if (fechaInicioNueva.isEmpty() ||
                    fechaFinNueva.isEmpty()) {

                Toast.makeText(
                        this,
                        "Seleccione las fechas",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // ----------------------------------------------------
            // Contacto
            // ----------------------------------------------------

            String contacto = "";

            int seleccionado =
                    rgContacto
                            .getCheckedRadioButtonId();

            if (seleccionado != -1) {

                RadioButton radioSeleccionado =
                        findViewById(seleccionado);

                contacto =
                        radioSeleccionado
                                .getText()
                                .toString();

            } else {

                Toast.makeText(
                        this,
                        "Seleccione cómo nos conoció",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // ====================================================
            // COMPROBAR DISPONIBILIDAD
            // ====================================================

            boolean disponible =
                    databaseHelper
                            .habitacionesDisponiblesEditar(
                                    idReservacion,
                                    habitacionesSeleccionadas,
                                    fechaInicioNueva,
                                    fechaFinNueva
                            );

            if (!disponible) {

                Toast.makeText(
                        this,
                        "Una de las habitaciones ya está reservada en esas fechas",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            // ====================================================
            // ACTUALIZAR RESERVACIÓN
            // ====================================================

            boolean actualizado =
                    databaseHelper
                            .actualizarReservacion(
                                    idReservacion,
                                    nombre,
                                    apellidoPaterno,
                                    apellidoMaterno,
                                    numeroPersonas,
                                    habitacionesSeleccionadas,
                                    tipoPago,
                                    costo,
                                    fechaInicioNueva,
                                    fechaFinNueva,
                                    contacto
                            );

            if (actualizado) {

                Toast.makeText(
                        this,
                        "Reservación actualizada correctamente",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Error al actualizar",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }

    // ============================================================
    // CARGAR HABITACIONES SELECCIONADAS
    // ============================================================

    private void cargarHabitacionesSeleccionadas(
            String habitacionesActuales) {

        for (int i = 0;
             i < seleccionados.length;
             i++) {

            seleccionados[i] = false;
        }

        if (habitacionesActuales == null ||
                habitacionesActuales.trim().isEmpty()) {

            return;
        }

        String[] guardadas =
                habitacionesActuales.split(",");

        for (String habitacion : guardadas) {

            String habitacionLimpia =
                    habitacion.trim();

            for (int i = 0;
                 i < habitaciones.length;
                 i++) {

                if (habitaciones[i]
                        .equals(habitacionLimpia)) {

                    seleccionados[i] = true;

                    break;
                }
            }
        }
    }

    // ============================================================
    // CARGAR FECHA DE INICIO EXISTENTE
    // ============================================================

    private void cargarFechaInicio(
            String fechaInicio) {

        if (fechaInicio == null ||
                fechaInicio.trim().isEmpty()) {

            fechaInicioSeleccionada = null;

            return;
        }

        SimpleDateFormat formato =
                new SimpleDateFormat(
                        "dd/MM/yyyy",
                        Locale.getDefault()
                );

        formato.setLenient(false);

        try {

            Date fecha =
                    formato.parse(
                            fechaInicio.trim()
                    );

            if (fecha != null) {

                fechaInicioSeleccionada =
                        Calendar.getInstance();

                fechaInicioSeleccionada
                        .setTime(fecha);
            }

        } catch (ParseException e) {

            fechaInicioSeleccionada = null;

            e.printStackTrace();
        }
    }

    // ============================================================
    // MOSTRAR HABITACIONES
    // ============================================================

    private void mostrarHabitaciones() {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        builder.setTitle(
                "Selecciona una habitación"
        );

        builder.setMultiChoiceItems(
                habitaciones,
                seleccionados,
                (dialog, which, isChecked) -> {

                    seleccionados[which] =
                            isChecked;
                }
        );

        builder.setPositiveButton(
                "Aceptar",
                (dialog, which) -> {

                    StringBuilder
                            habitacionesSeleccionadas =
                            new StringBuilder();

                    totalHabitaciones = 0;

                    for (int i = 0;
                         i < habitaciones.length;
                         i++) {

                        if (seleccionados[i]) {

                            if (habitacionesSeleccionadas
                                    .length() > 0) {

                                habitacionesSeleccionadas
                                        .append(", ");
                            }

                            habitacionesSeleccionadas
                                    .append(
                                            habitaciones[i]
                                    );

                            totalHabitaciones +=
                                    precios[i];
                        }
                    }

                    cuartoSpinner.setText(
                            habitacionesSeleccionadas
                                    .toString()
                    );

                    String tipoPago =
                            spPago
                                    .getSelectedItem()
                                    .toString();

                    if (tipoPago.equals("Pago total")) {

                        costoEdit.setText(
                                String.valueOf(
                                        totalHabitaciones
                                )
                        );

                    } else if (tipoPago.equals("Sin anticipo")) {

                        costoEdit.setText("0");
                    }

                    Toast.makeText(
                            Modificar.this,
                            "Total de habitaciones: $" +
                                    totalHabitaciones,
                            Toast.LENGTH_SHORT
                    ).show();
                }
        );

        builder.show();
    }

    // ============================================================
    // CALENDARIO FECHA INICIAL
    // ============================================================

    private void mostrarCalendarioInicio() {

        Calendar calendario =
                Calendar.getInstance();

        int año =
                calendario.get(Calendar.YEAR);

        int mes =
                calendario.get(Calendar.MONTH);

        int dia =
                calendario.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog =
                new DatePickerDialog(
                        this,
                        (view,
                         year,
                         month,
                         dayOfMonth) -> {

                            fechaInicioSeleccionada =
                                    Calendar.getInstance();

                            fechaInicioSeleccionada.set(
                                    year,
                                    month,
                                    dayOfMonth,
                                    0,
                                    0,
                                    0
                            );

                            fechaInicioSeleccionada.set(
                                    Calendar.MILLISECOND,
                                    0
                            );

                            SimpleDateFormat formato =
                                    new SimpleDateFormat(
                                            "dd/MM/yyyy",
                                            Locale.getDefault()
                                    );

                            fechainEdit.setText(
                                    formato.format(
                                            fechaInicioSeleccionada
                                                    .getTime()
                                    )
                            );

                            // Si la fecha final existente
                            // queda antes de la nueva fecha inicial,
                            // se elimina.

                            if (!fechafinEdit
                                    .getText()
                                    .toString()
                                    .trim()
                                    .isEmpty()) {

                                try {

                                    Date fechaFinal =
                                            formato.parse(
                                                    fechafinEdit
                                                            .getText()
                                                            .toString()
                                                            .trim()
                                            );

                                    if (fechaFinal != null &&
                                            fechaFinal.before(
                                                    fechaInicioSeleccionada
                                                            .getTime()
                                            )) {

                                        fechafinEdit
                                                .setText("");

                                        Toast.makeText(
                                                this,
                                                "La fecha final fue eliminada porque es anterior a la nueva fecha inicial",
                                                Toast.LENGTH_SHORT
                                        ).show();
                                    }

                                } catch (ParseException e) {

                                    e.printStackTrace();
                                }
                            }

                        },
                        año,
                        mes,
                        dia
                );

        datePickerDialog.show();
    }

    // ============================================================
    // CALENDARIO FECHA FINAL
    // ============================================================

    private void mostrarCalendarioFin() {

        // Si por alguna razón no existe la fecha en Calendar,
        // intentar cargarla desde el EditText.

        if (fechaInicioSeleccionada == null) {

            cargarFechaInicio(
                    fechainEdit
                            .getText()
                            .toString()
            );
        }

        if (fechaInicioSeleccionada == null) {

            Toast.makeText(
                    this,
                    "Primero seleccione la fecha de inicio",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Calendar calendario =
                Calendar.getInstance();

        int año =
                calendario.get(Calendar.YEAR);

        int mes =
                calendario.get(Calendar.MONTH);

        int dia =
                calendario.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog =
                new DatePickerDialog(
                        this,
                        (view,
                         year,
                         month,
                         dayOfMonth) -> {

                            Calendar fechaFin =
                                    Calendar.getInstance();

                            fechaFin.set(
                                    year,
                                    month,
                                    dayOfMonth,
                                    0,
                                    0,
                                    0
                            );

                            fechaFin.set(
                                    Calendar.MILLISECOND,
                                    0
                            );

                            SimpleDateFormat formato =
                                    new SimpleDateFormat(
                                            "dd/MM/yyyy",
                                            Locale.getDefault()
                                    );

                            fechafinEdit.setText(
                                    formato.format(
                                            fechaFin.getTime()
                                    )
                            );
                        },
                        año,
                        mes,
                        dia
                );

        // No permitir fechas anteriores a la fecha inicial.

        datePickerDialog
                .getDatePicker()
                .setMinDate(
                        fechaInicioSeleccionada
                                .getTimeInMillis()
                );

        datePickerDialog.show();
    }
}

