package com.beit.myapplication;

import android.widget.RadioGroup;
import android.widget.RadioButton;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Spinner;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Locale;
import android.app.DatePickerDialog;
import java.util.Date;

public class Registro extends AppCompatActivity {

    private RadioGroup rgContacto;
    private RadioButton rbFacebook;
    private RadioButton rbInstagram;
    private RadioButton rbBooking;
    private RadioButton rbAirbnb;
    private EditText fechainEdit;
    private EditText fechafinEdit;
    private Calendar fechaInicioSeleccionada;
    private EditText costoEdit;
    private EditText nameEdit;
    private EditText apepaEdit;
    private EditText apemaEdit;
    private Button btnRegistrar;
    private EditText cuartoSpinner;
    private final String[] habitaciones={ "101","102","103","201","202","203","204" };
    private final int[] precios={ 1600,1600,800,850,1200,650,650 };
    private final boolean[] seleccionados = new boolean[habitaciones.length];
    private double totalHabitaciones=0;
    private EditText personaEdit;
    private DatabaseHelper databaseHelper;
    private Spinner spPago;

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        nameEdit = findViewById(R.id.nameEdit);
        apepaEdit = findViewById(R.id.apepaEdit);
        apemaEdit= findViewById(R.id.apemaEdit);
        personaEdit= findViewById(R.id.personaEdit);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        cuartoSpinner=findViewById(R.id.cuartoSpinner);
        costoEdit = findViewById(R.id.costoEdit);
        spPago = findViewById(R.id.spPago);
        fechainEdit = findViewById(R.id.fechainEdit);
        fechafinEdit = findViewById(R.id.fechafinEdit);
        rgContacto = findViewById(R.id.rgContacto);
        rbFacebook = findViewById(R.id.rbFacebook);
        rbInstagram = findViewById(R.id.rbInstagram);
        rbBooking = findViewById(R.id.rbBooking);
        rbAirbnb = findViewById(R.id.rbAirbnb);

        databaseHelper = new DatabaseHelper(this);

        cuartoSpinner.setOnClickListener(v ->{
            mostrarHabitaciones();});

        btnRegistrar.setOnClickListener(v -> {

            String nombre = nameEdit.getText().toString();
            String apellidoPaterno = apepaEdit.getText().toString();
            String apellidoMaterno = apemaEdit.getText().toString();
            int numeroPersonas = Integer.parseInt(personaEdit.getText().toString());

            String habitacionesSeleccionadas = cuartoSpinner.getText().toString();
            String tipoPago = spPago.getSelectedItem().toString();

            double costo = 0;

            if (!costoEdit.getText().toString().isEmpty()) {
                costo = Double.parseDouble(costoEdit.getText().toString());
            }

            String fechaInicio = fechainEdit.getText().toString();
            String fechaFin = fechafinEdit.getText().toString();


            // Obtener contacto
            String contacto = "";

            int seleccionado = rgContacto.getCheckedRadioButtonId();

            if (seleccionado != -1) {

                RadioButton radioSeleccionado = findViewById(seleccionado);

                contacto = radioSeleccionado.getText().toString();

            } else {

                Toast.makeText(
                        this,
                        "Seleccione cómo nos conoció",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }


            // Validar disponibilidad
            boolean disponible = databaseHelper.habitacionesDisponibles(
                    habitacionesSeleccionadas,
                    fechaInicio,
                    fechaFin
            );

            if (!disponible) {

                Toast.makeText(
                        this,
                        "Una de las habitaciones ya está reservada en esas fechas",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }


            boolean guardado = databaseHelper.insertarCliente(
                    nombre,
                    apellidoPaterno,
                    apellidoMaterno,
                    numeroPersonas,
                    habitacionesSeleccionadas,
                    tipoPago,
                    costo,
                    fechaInicio,
                    fechaFin,
                    contacto
            );
            if (guardado) {

                Reservacion nuevaReservacion =
                        new Reservacion(
                                0,
                                nombre,
                                apellidoPaterno,
                                apellidoMaterno,
                                numeroPersonas,
                                habitacionesSeleccionadas,
                                tipoPago,
                                costo,
                                fechaInicio,
                                fechaFin,
                                contacto
                        );
            }
            if (guardado){

                Toast.makeText(
                        this,
                        "Datos guardados correctamente",
                        Toast.LENGTH_SHORT
                ).show();

            }else{

                Toast.makeText(
                        this,
                        "Error al guardar datos",
                        Toast.LENGTH_SHORT
                ).show();

            }

        });

        fechainEdit.setOnClickListener(v -> mostrarCalendarioInicio());
        fechafinEdit.setOnClickListener(v -> mostrarCalendarioFin());
        String[] tiposPago = {
                "Pago total",
                "Con anticipo",
                "Sin anticipo"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                tiposPago
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spPago.setAdapter(adapter);
        spPago.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {

                String tipoPago = parent.getItemAtPosition(position).toString();

                if (tipoPago.equals("Pago total")) {

                    costoEdit.setText(String.valueOf(totalHabitaciones));

                    costoEdit.setFocusable(false);
                    costoEdit.setFocusableInTouchMode(false);
                    costoEdit.setClickable(false);

                } else if (tipoPago.equals("Con anticipo")) {

                    costoEdit.setText("");

                    costoEdit.setFocusable(true);
                    costoEdit.setFocusableInTouchMode(true);
                    costoEdit.setClickable(true);

                } else if (tipoPago.equals("Sin anticipo")) {

                    costoEdit.setText("0");

                    costoEdit.setFocusable(false);
                    costoEdit.setFocusableInTouchMode(false);
                    costoEdit.setClickable(false);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    private void  mostrarHabitaciones(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona una habitacion");

        builder.setMultiChoiceItems(habitaciones,seleccionados,
                (dialog, which, isChecked) ->{
                seleccionados[which]= isChecked;
    });
        builder.setPositiveButton("Aceptar", (dialog, which) -> {

            StringBuilder habitacionesSeleccionadas = new StringBuilder();

            totalHabitaciones = 0;

            for (int i = 0; i < habitaciones.length; i++) {

                if (seleccionados[i]) {
                    if (habitacionesSeleccionadas.length() > 0) {
                        habitacionesSeleccionadas.append(", ");
                    }
                    habitacionesSeleccionadas.append(habitaciones[i]);
                    totalHabitaciones += precios[i];
                }
            }
            cuartoSpinner.setText(habitacionesSeleccionadas.toString());
            // Actualiza el costo según el tipo de pago seleccionado
            String tipoPago = spPago.getSelectedItem().toString();
            if (tipoPago.equals("Pago total")) {
                costoEdit.setText(String.valueOf(totalHabitaciones));
            } else if (tipoPago.equals("Sin anticipo")) {
                costoEdit.setText("0");
            }
            Toast.makeText(Registro.this, "Total de habitaciones: $" + totalHabitaciones, Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }
    private void mostrarCalendarioInicio() {

        Calendar calendario = Calendar.getInstance();

        int año = calendario.get(Calendar.YEAR);
        int mes = calendario.get(Calendar.MONTH);
        int dia = calendario.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {

                    fechaInicioSeleccionada = Calendar.getInstance();
                    fechaInicioSeleccionada.set(year, month, dayOfMonth);

                    SimpleDateFormat formato =
                            new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

                    fechainEdit.setText(formato.format(fechaInicioSeleccionada.getTime()));
                    // Verificar si existe una fecha final seleccionada
                    if (!fechafinEdit.getText().toString().isEmpty()) {

                        try {

                            Date fechaFinal = formato.parse(
                                    fechafinEdit.getText().toString()
                            );

                            // Si la fecha final queda antes de la nueva fecha inicial
                            if (fechaFinal.before(fechaInicioSeleccionada.getTime())) {

                                fechafinEdit.setText("");

                                Toast.makeText(
                                        this,
                                        "La fecha final fue eliminada porque es anterior a la nueva fecha inicial",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                },
                año,
                mes,
                dia
        );

        datePickerDialog.show();
    }
    private void mostrarCalendarioFin() {

        // Verificar que primero se haya seleccionado la fecha de inicio
        if (fechaInicioSeleccionada == null) {
            Toast.makeText(this,
                    "Primero seleccione la fecha de inicio",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        Calendar calendario = Calendar.getInstance();

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {

                    Calendar fechaFin = Calendar.getInstance();
                    fechaFin.set(year, month, dayOfMonth);

                    SimpleDateFormat formato =
                            new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

                    fechafinEdit.setText(formato.format(fechaFin.getTime()));

                },
                calendario.get(Calendar.YEAR),
                calendario.get(Calendar.MONTH),
                calendario.get(Calendar.DAY_OF_MONTH)
        );

        // No permitir fechas anteriores a la fecha de inicio
        datePickerDialog.getDatePicker().setMinDate(fechaInicioSeleccionada.getTimeInMillis());

        datePickerDialog.show();
    }



}