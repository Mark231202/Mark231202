package com.beit.myapplication;

import android.app.Activity;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.Toast;
import android.content.Intent;

import java.util.ArrayList;

public class ReservacionAdapter extends ArrayAdapter<Reservacion> {

    private final Activity context;
    private final ArrayList<Reservacion> lista;

    public ReservacionAdapter(Activity context, ArrayList<Reservacion> lista) {
        super(context, R.layout.item_reservacion, lista);
        this.context = context;
        this.lista = lista;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View fila = convertView;

        if (fila == null) {
            LayoutInflater inflater = context.getLayoutInflater();
            fila = inflater.inflate(R.layout.item_reservacion, parent, false);
        }

        Reservacion reservacion = lista.get(position);

        TextView txtNombre = fila.findViewById(R.id.txtNombre);
        TextView txtInfo = fila.findViewById(R.id.txtInfo);
        ImageButton btnEditar = fila.findViewById(R.id.btnEditar);
        ImageButton btnEliminar = fila.findViewById(R.id.btnEliminar);

        txtNombre.setText(
                reservacion.getNombre() + " " +
                        reservacion.getApellidoPaterno() + " " +
                        reservacion.getApellidoMaterno()
        );

        txtInfo.setText(
                "👥 Personas: " + reservacion.getNumeroPersonas() +
                        "\n🛏 Habitaciones: " + reservacion.getHabitaciones() +
                        "\n💳 Pago: " + reservacion.getTipoPago() +
                        "\n💵 Costo: $" + reservacion.getCosto() +
                        "\n📅 " + reservacion.getFechaInicio() + " - " + reservacion.getFechaFin() +
                        "\n📢 Contacto: " + reservacion.getContacto()
        );
        btnEditar.setOnClickListener(v -> {

            Intent intent = new Intent(context, Modificar.class);

            intent.putExtra("editar", true);
            intent.putExtra("id", reservacion.getId());
            intent.putExtra("nombre", reservacion.getNombre());
            intent.putExtra("apellidoPaterno", reservacion.getApellidoPaterno());
            intent.putExtra("apellidoMaterno", reservacion.getApellidoMaterno());
            intent.putExtra("numeroPersonas", reservacion.getNumeroPersonas());
            intent.putExtra("habitaciones", reservacion.getHabitaciones());
            intent.putExtra("tipoPago", reservacion.getTipoPago());
            intent.putExtra("costo", reservacion.getCosto());
            intent.putExtra("fechaInicio", reservacion.getFechaInicio());
            intent.putExtra("fechaFin", reservacion.getFechaFin());
            intent.putExtra("contacto", reservacion.getContacto());

            context.startActivity(intent);

        });
        // BOTÓN ELIMINAR
        btnEliminar.setOnClickListener(v -> {

            new AlertDialog.Builder(context)
                    .setTitle("Eliminar reservación")
                    .setMessage("¿Está seguro de eliminar la reservación de " +
                            reservacion.getNombre() + "?")
                    .setPositiveButton("Eliminar", (dialog, which) -> {

                        DatabaseHelper db = new DatabaseHelper(context);

                        boolean eliminado = db.eliminarReservacion(reservacion.getId());

                        if (eliminado) {

                            lista.remove(position);

                            notifyDataSetChanged();

                            Toast.makeText(
                                    context,
                                    "Reservación eliminada correctamente",
                                    Toast.LENGTH_SHORT
                            ).show();

                        } else {

                            Toast.makeText(
                                    context,
                                    "Error al eliminar",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }

                    })
                    .setNegativeButton("Cancelar", null)
                    .show();

        });

        return fila;
    }


}